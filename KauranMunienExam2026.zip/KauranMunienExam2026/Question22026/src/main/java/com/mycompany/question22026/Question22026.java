/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question22026;
import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;

/**
 *
 * @author Student
 */
public class Question22026 extends JFrame {
// Interface
    interface IProductCalculations {

        double GetVAT(
                int productsales, double Vat){
        
        
        Vat=productsales*0.15;
        return Vat;
       
        };

        double GetCommision(
                int productsales, double Commission){
        
        Commission=productsales*0.05;
        return Commission;
        
        
        
        };
        
         double GetTotal(
                int productsales,double Vat,double Commission, double totalprice){
         

            

            totalprice =productsales + Vat+ Commission ;
            return totalprice;
            
         
         };
    }

    
    static class ProductsClassData {
String CustomerName;
        int productsales;
        double Vat;
        double Commission;
        double totalprice;
        

        public ProductClassData(String CustomerName,
        int productsales,
        double Vat,
        double Commission,
        double totalprice) {

            this.CustomerName = CustomerName;
            this.productsales = productsales;
            this.Vat = Vat;
            this.Commission = Commission;
            this.totalprice = totalprice;
            
            
            
            
            
        }
    }

    


    // GUI components
    JComboBox<String> cmbSelectProduct;
    JTextField txtCustomername;
    JTextField txtPriceofProduct;
    JTextArea txtReport;
JButton btnPROCESS;
    

    // Constructor
    public Question22026() {

        setTitle("Product App");
        setSize(500, 450);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        createMenu();
        createForm();
    }

    // Create menu
    public void createMenu() {

        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        JMenuItem exitItem = new JMenuItem("Exit");
        JMenuItem processItem = new JMenuItem("Process");
        JMenuItem clearItem = new JMenuItem("Clear");

        // Exit menu
        exitItem.addActionListener(e -> System.exit(0));

        // Process menu
        processItem.addActionListener(e -> processTickets());

        // Clear menu
        clearItem.addActionListener(e -> clearForm());

        fileMenu.add(exitItem);

        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        setJMenuBar(menuBar);
    }

    // Create form
    public void createForm() {

        JPanel panel = new JPanel(new GridLayout(3, 2, 10, 10));

        panel.setBorder(
                BorderFactory.createEmptyBorder(20, 20, 20, 20));

        
        
        // Number of tickets
        JLabel lblCustomername = new JLabel("Customer Name:");

        txtCustomername = new JTextField();
        
        // Movie selection
        JLabel lblSelectProduct = new JLabel("Select Product:");

        cmbSelectProduct = new JComboBox<>(new String[]{
            "Cozy Nights Monarch",
            "Restonic Barbados",
            "Sealy Phuket"
        });

        
        // Ticket price
        JLabel lblProductPrice = new JLabel("Enter Price:");

        txtPriceofProduct = new JTextField();
        
        panel.add(lblCustomername);
        panel.add(txtCustomername);
        panel.add(lblSelectProduct);
        panel.add(cmbSelectProduct);

        panel.add(lblProductPrice);
        panel.add(txtPriceofProduct);

        panel.add(btnPROCESS);
        
    }

    // Process movie tickets
    public void processTickets() {

        try {

            // Capture input
            String Selectproduct =
                    cmbSelectProduct.getSelectedItem().toString();

            String CustomerName =
                    (txtCustomername.getText());

            double productsales =
                    Double.parseDouble(txtPriceofProduct.getText());

            
            // Create MovieTicketData object
            productsalesData data = new ProductSalesData(
                    CustomerName,
                    Selectproduct,
                    productsales
            );

            

            // Calculate subtotal
            double subtotal = numberOfTickets * ticketPrice;

            // Calculate VAT
            double vat = subtotal * 0.14;

            // Calculate total price
            double total = tickets.CalculateTotalTicketPrice(
                    numberOfTickets, ticketPrice);

            // Generate report
            String report = String.format(
                    "DATA LOG\n\n"
                    +"*************************************************"        
                    + "Customer Name: %s\n"
                    + "Product: %d\n"
                    + "VAT: R %.2f\n"
                    + "COMMISSION: R %.2f\n"
                    + "TOTAL : R %.2f"
                    +"*************************************************",
                   CustomerName,
                    productsales,
                   Vat,
                   Commision,
                    totalprice
            );

            // Display report
            txtReport.setText(report);

            // Save report to text file
            saveReport(report);

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter valid numbers for price!",
                    "Input Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Save report
    public void saveReport(String report) {

        try {

            PrintWriter writer =
                    new PrintWriter(new FileWriter("data.txt"));

            writer.println(report);

            writer.close();

            JOptionPane.showMessageDialog(
                    this,
                    "Report saved successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (IOException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Error saving report!",
                    "File Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Clear form
    public void clearForm() {

        cmbSelectProduct.setSelectedIndex(0);

        txtCustomername.setText("");

        txtPriceofProduct.setText("");

        
    }

    public static void main(String[] args) {
      
        SwingUtilities.invokeLater(() -> {

            Question22026 form = new Question22026();

            form.setVisible(true);
        });
    }
}
