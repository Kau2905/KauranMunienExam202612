/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.question22026;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class Question22026Test {
    
    public Question22026Test() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of createMenu method, of class Question22026.
     */
    @Test
    public void testCreateMenu() {
        System.out.println("createMenu");
        Question22026 instance = new Question22026();
        instance.createMenu();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of createForm method, of class Question22026.
     */
    @Test
    public void testCreateForm() {
        System.out.println("createForm");
        Question22026 instance = new Question22026();
        instance.createForm();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of processTickets method, of class Question22026.
     */
    @Test
    public void testProcessTickets() {
        System.out.println("processTickets");
        Question22026 instance = new Question22026();
        instance.processTickets();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of saveReport method, of class Question22026.
     */
    @Test
    public void testSaveReport() {
        System.out.println("saveReport");
        String report = "";
        Question22026 instance = new Question22026();
        instance.saveReport(report);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of clearForm method, of class Question22026.
     */
    @Test
    public void testClearForm() {
        System.out.println("clearForm");
        Question22026 instance = new Question22026();
        instance.clearForm();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Question22026.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Question22026.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
