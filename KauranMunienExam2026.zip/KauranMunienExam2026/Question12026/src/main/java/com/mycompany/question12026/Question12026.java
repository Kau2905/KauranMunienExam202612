/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.question12026;

/**
 *
 * @author Student
 */
public class Question12026 {
// Interface
    interface IProduct {

        int GetTotalProductsSold(int[][] totalproductSales);

        double GetAverageProductSold(int[][] productSales);

        String GetMostPopularProduct(String productname);
    }

    // ProductSales class
    static class Products implements IProduct {

        @Override
        public int GetTotalProductsSold(int[][] productSales) {

            int total = 0;

            for (int i = 0; i < productSales.length; i++) {
                for (int j = 0; j < productSales[i].length; j++) {
                    total += productSales[i][j];
                }
            }

            return total;
        }

        @Override
        public double GetAverageProductSold(int[][] productSales) {

            int total = GetTotalProductsSold(productSales);
            int count = 0;

            for (int i = 0; i < productSales.length; i++) {
                count += productSales[i].length;
            }

            return (double) total / count;
        }

        
    }
    public static void main(String[] args) {
        // Two-dimensional array
        int[][] productSales = {
            {25, 18, 20},
            {15, 10, 12},
            {18,15,20}
                
        };

    
String[] SalesofProductsinPlacesCozy = {
            "Enter number of sales for month 1 for Cozy Nights Monarch mattress",
            "Enter number of sales for month 2 for Cozy Nights Monarch mattress",
            "Enter number of sales for month 3 for Cozy Nights Monarch mattress"
        };


String[] SalesofProductsinPlacesRestonicBarbados = {
            "Enter number of sales for month 1 for Restonic Barbados  mattress",
            "Enter number of sales for month 2 for Restonic Barbados mattress",
            "Enter number of sales for month 3 for Restonic Barbados  mattress"
        };

String[] SalesofProductsinPlacesSealyPhuket = {
            "Enter number of sales for month 1 for Sealy Phuket mattress",
            "Enter number of sales for month 2 for Sealy Phuket mattress",
            "Enter number of sales for month 3 for Sealy Phuket mattress"
        };
// Single-dimensional array
        int[] allSales = new int[6];

        int index = 0;

        for (int i = 0; i < productSales.length; i++) {
            for (int j = 0; j < productSales[i].length; j++) {

                allSales[index] = productSales[i][j];
                index++;
            }
        }

        // Create ProductSales object
        Products sales = new Products();

        // Display report
        
        System.out.println("       PRODUCT SALES REPORT - 2026");
        System.out.println("================================");

        System.out.println("Total Sales: R" +
                sales.GetTotalProductsSold(productSales));

        System.out.println("Average Sales: R" +
        Math.round(sales.GetAverageProductSold(productSales)));

      
        System.out.println("================================");
    }

}

        

